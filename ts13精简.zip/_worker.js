import { connect } from 'cloudflare:sockets';
//说明：ts13精简版，自己手戳节点，支持基础反代路径传参/pyip=，建议pages部署
let 福利姬 = ""; //建议修改为自己的规范化UUID
//////////////////////////////////////////////////////////////////////////反代配置/////////////////////////////////////////////////////////////////////////
let 启用反代功能 = false
let 反代IP = '' //反代IP或域名，反代IP端口一般情况下不用填写，如果你非要用非标反代的话，可以填'ts.hpc.tw:443'这样
//////////////////////////////////////////////////////////////////////////DOH配置/////////////////////////////////////////////////////////////////////////
let 启用DOH查询转换 = true
let 严格TTL缓存 = true //新增了脚本本地缓存，可以维持几分钟甚至几小时左右，如果启用则严格按照TTL时间进行缓存，关闭可减少频繁查询的次数，提升速度，个人视使用环境选择
let DOH服务器列表 = [
  "https://dns.google/resolve",
];
//////////////////////////////////////////////////////////////////////////流控配置////////////////////////////////////////////////////////////////////////
let 启动控流机制 = true
let 传输控流大小 = 64; //单位字节，相当于分片大小
//////////////////////////////////////////////////////////////////////////主要架构////////////////////////////////////////////////////////////////////////
export default {
  async fetch(访问请求) {
    if (访问请求.headers.get('Upgrade') === 'websocket'){
      const 读取路径 = 访问请求.url.replace(/^https?:\/\/[^/]+/, '');
      const 匹配反代IP = 读取路径.match(/pyip=([^&]+)/)?.[1];
      if (匹配反代IP) {
        启用反代功能 = true;
        反代IP = 匹配反代IP;
      } else {
        反代IP = 反代IP;
      }
      const [客户端, WS接口] = Object.values(new WebSocketPair());
      WS接口.accept();
      WS接口.send(new Uint8Array([0, 0]));
      启动传输管道(WS接口);
      return new Response(null, { status: 101, webSocket: 客户端 }); //一切准备就绪后，回复客户端WS连接升级成功
    } else {
      return new Response('Hello World!', { status: 200 });
    }
  }
};
async function 启动传输管道(WS接口) {
  let 识别地址类型, 访问地址, 地址长度, TCP接口, 首包数据 = false, 首包处理完成 = null, 传输数据, 读取数据, 传输队列 = Promise.resolve(), 开始传输时间 = performance.now();
  try {
    WS接口.addEventListener('message', async event => {
      if (!首包数据) {
        首包数据 = true;
        首包处理完成 = 解析首包数据(event.data);
        传输队列 = 传输队列.then(() => 首包处理完成).catch();
      } else {
        await 首包处理完成;
        传输队列 = 传输队列.then(async () => await 传输数据.write(event.data)).catch();
      }
    });
    async function 解析首包数据(首包数据) {
      const 二进制数据 = new Uint8Array(首包数据);
      const 验证VL的密钥 = (a, i = 0) => [...a.slice(i, i + 16)].map(b => b.toString(16).padStart(2, '0')).join('').replace(/(.{8})(.{4})(.{4})(.{4})(.{12})/, '$1-$2-$3-$4-$5');
      if (福利姬 && 验证VL的密钥(二进制数据.slice(1, 17)) !== 福利姬) throw new Error('UUID验证失败');
      const 提取端口索引 = 18 + 二进制数据[17] + 1;
      const 访问端口 = new DataView(二进制数据.buffer, 提取端口索引, 2).getUint16(0);
      if (访问端口 === 53) {
        const 提取DNS查询报文 = 二进制数据.slice(提取端口索引 + 9);
        const 查询DOH结果 = await fetch('https://dns.google/dns-query', {
          method: 'POST',
          headers: {
            'content-type': 'application/dns-message',
          },
          body: 提取DNS查询报文
        })
        const 提取DOH结果 = await 查询DOH结果.arrayBuffer();
        const 构建长度头部 = new Uint8Array([(提取DOH结果.byteLength >> 8) & 0xff, 提取DOH结果.byteLength & 0xff]);
        WS接口.send(await new Blob([构建长度头部, 提取DOH结果]));
        return;
      }
      const 提取地址索引 = 提取端口索引 + 2;
      识别地址类型 = 二进制数据[提取地址索引];
      let 地址信息索引 = 提取地址索引 + 1;
      switch (识别地址类型) {
        case 1:
          地址长度 = 4;
          访问地址 = 二进制数据.slice(地址信息索引, 地址信息索引 + 地址长度).join('.');
          break;
        case 2:
          地址长度 = 二进制数据[地址信息索引];
          地址信息索引 += 1;
          const 访问域名 = new TextDecoder().decode(二进制数据.slice(地址信息索引, 地址信息索引 + 地址长度));
          if (启用DOH查询转换) {
            访问地址 = await 查询最快IP(访问域名);
            const 匹配结果 = 匹配地址(访问地址);
            if (匹配结果.类型 === 'ipv4') 识别地址类型 = 1;
          } else {
            访问地址 = 访问域名;
          }
          break;
        default:
          throw new Error ('无效的访问地址');
      }
      try {
        TCP接口 = connect({ hostname: 访问地址, port: 访问端口 });
        await TCP接口.opened;
      } catch {
        if (启用反代功能) {
          let [反代IP地址, 反代IP端口] = 解析地址端口(反代IP);
          TCP接口 = connect({ hostname: 反代IP地址, port: 反代IP端口});
        }
      }
      await TCP接口.opened;
      传输数据 = TCP接口.writable.getWriter();
      读取数据 = TCP接口.readable.getReader();
      const 写入初始数据 = 二进制数据.slice(地址信息索引 + 地址长度)
      if(写入初始数据) await 传输数据.write(写入初始数据);
      启动回传管道();
    }
    async function 启动回传管道() {
      while (true) {
        const { done: 流结束, value: 返回数据 } = await 读取数据.read();
        if (返回数据 && 返回数据.length > 0) {
          if (启动控流机制) {
            let 分段初值 = 0
            let 分段大小 = 传输控流大小;
            while (分段初值 < 返回数据.length) {
              const 数据块 = 返回数据.slice(分段初值, 分段初值 + 分段大小);
              传输队列 = 传输队列.then(() => WS接口.send(数据块)).catch();
              分段初值 += 分段大小;
            }
          } else {
            传输队列 = 传输队列.then(() => WS接口.send(返回数据)).catch();
          }
        }
        if (流结束) break;
      }
    }
  } catch (e) {
    return new Response(`连接握手失败: ${e}`, { status: 500 });
  }
}
function 匹配地址(地址) {
  const 是IPv4 = /^(?:(?:1\d{2}|2[0-1]\d|22[0-3]|[1-9]?\d)(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){3})$/.test(地址);
  return {
    是IP: 是IPv4,
    类型: 是IPv4 ? "ipv4" : null
  };
}
globalThis.DNS缓存记录 = globalThis.DNS缓存记录 ??= new Map();
async function 查询最快IP(访问域名) {
  let 获取dns结果, 获取dnsTTL, DOH结果;
  let 读取缓存时间 = DNS缓存记录.get('缓存保活');
  if (!读取缓存时间) DNS缓存记录.set('缓存保活', { 缓存时间: Date.now() });
  const 进程控制器 = [];
  const 开始查询时间 = Date.now();
  let 查询DNS缓存记录 = DNS缓存记录.get(访问域名);
  if (查询DNS缓存记录 && (!严格TTL缓存 || 开始查询时间 < 查询DNS缓存记录.TTL过期时间)) {
    return 查询DNS缓存记录.IP;
  }
  const 构造所有请求 = (type) => {
    const 请求列表 = [];
    const 构造DOH请求 = (type) => 
      DOH服务器列表.map(DOH => {
        const 取消控制器 = new AbortController();
        进程控制器.push(取消控制器);
        return fetch(`${DOH}?name=${访问域名}&type=${type}`, {
          method: 'POST',
          headers: { 'Accept': 'application/dns-json' },
          signal: 取消控制器.signal
        }).then(res => res.json())
          .then(json => {
            const 查询结果 = json.Answer?.filter(r => r.type === (type === 'A' ? 1 : 28)).pop();
            if (查询结果?.data) {
              return [查询结果.data, 查询结果.TTL ?? 120, DOH];
            }
            return Promise.reject(`无 ${type} 记录`);
          })
          .catch(err => Promise.reject(`${DOH} ${type} 请求失败: ${err}`));
      });
    请求列表.push(...构造DOH请求(type));
    return 请求列表;
  };
  try {
    [获取dns结果, 获取dnsTTL, DOH结果] = await Promise.any(构造所有请求('A'));
    const 匹配结果 = 匹配地址(获取dns结果);
    if (!匹配结果.是IP) throw new Error ('获取IP地址失败')
    return 获取dns结果;
  } catch {
    return 访问域名;
  } finally {
    try { 进程控制器.forEach(取消控制器 => 取消控制器.abort()) } catch {};
    const 匹配结果 = 匹配地址(获取dns结果);
    if (匹配结果.是IP && 获取dnsTTL) {
      const 更新时间 = new Date(开始查询时间 + 8 * 60 * 60 * 1000)
      .toLocaleString('zh-CN', { hour12: false })
      .replace(/\//g, '-');
      const TTL过期时间 = 开始查询时间 + 获取dnsTTL * 1000;
      DNS缓存记录.set(访问域名, {
        域名: 访问域名,
        IP: 获取dns结果,
        更新时间: 更新时间,
        TTL: 获取dnsTTL,
        TTL更新时间: 开始查询时间,
        TTL过期时间: TTL过期时间,
        缓存时间: Date.now()
      });
    }
  }
}
function 解析地址端口(地址段) {
  let 地址, IPV6地址, 端口;
  if (地址段.startsWith('[')) {
    [IPV6地址, 端口 = 443] = 地址段.slice(1, -1).split(']:');
    地址 = `[${IPV6地址}]`
  } else {
    [地址, 端口 = 443] = 地址段.split(':')
  }
  return [地址, 端口];
}
function 格式化时间(毫秒数) {
  const 总毫秒 = 毫秒数;
  const 小时 = Math.floor(总毫秒 / (3600 * 1000));
  const 分钟 = Math.floor((总毫秒 % (3600 * 1000)) / (60 * 1000));
  const 秒 = Math.floor((总毫秒 % (60 * 1000)) / 1000);
  const 毫秒 = 总毫秒 % 1000;
  return `${小时.toString().padStart(2, '0')}:${分钟.toString().padStart(2, '0')}:${秒.toString().padStart(2, '0')}.${毫秒.toString().padStart(3, '0')}`;
}